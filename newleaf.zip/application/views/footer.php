<footer class="footer">

    <ul class="social-icon animate pull-right">
        <div class="container">



            <font color="red"> <b>Follow Us : </b> </font>        <li><a href="#" title="facebook" target="_blank"><i class="fa fa-facebook"></i></a></li> <!-- change the link to social page and edit title-->
            <li><a href="#" title="twitter" target="_blank"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#" title="google plus" target="_blank"><i class="fa fa-google-plus"></i></a></li>
    </ul>
</footer>