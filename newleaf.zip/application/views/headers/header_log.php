        <header>
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <style>
                            .img2{
                                vertical-align: middle;
                                margin-top: -12px;
                            }

                        </style>
                        <img src="<?php echo base_url() ?>images/logo5.png" class="img2">

                    </div>
                    <div class="col-sm-6 hidden-xs">

                    </div>
                </div>
            </div>
        </header>
